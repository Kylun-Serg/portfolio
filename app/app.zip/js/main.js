$(function(){

var mixer = mixitup('.works__items-inner');

  
});